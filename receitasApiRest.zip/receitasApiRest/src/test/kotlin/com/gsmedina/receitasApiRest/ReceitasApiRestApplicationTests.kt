package com.gsmedina.receitasApiRest

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class ReceitasApiRestApplicationTests {

	@Test
	fun contextLoads() {
	}

}
