package com.gsmedina.receitasApiRest.enums

//Definicao de constante
enum class PerfilEnum {
    ROLE_USUARIO
}